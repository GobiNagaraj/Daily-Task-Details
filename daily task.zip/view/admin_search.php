<?php 

  session_start();
  include_once '../model/db.php';
  $sql = "SELECT * FROM `task_details` WHERE `user_name` LIKE '".$_POST['emp_search']."%'";
  $result = mysqli_query($conn,$sql);
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>EdCloud Task Page</title>
  <!-- Bootstrap core CSS-->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin.css" rel="stylesheet">
  <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
</head>

<style type="text/css">
  #dataTable_filter
  {
    display: none;
  }
</style>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
 
       <?php include_once 'admin_menu.php';?>
<div class="content-wrapper">
    <div class="container-fluid">
       <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Daily Task</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Employee Name</th>
                  <th>Task Name</th>
                  <th>Task Description</th>
                  <th>Remark &amp; Update</th>
                  <th>Attachements</th>
                </tr>
              <tbody>
              <?php $j = 0;
              while($row = mysqli_fetch_array($result)){?>
              <tr>
                <td><?php echo $j+1 ;?></td>
                <td><?php echo $row['date'];?></td>
                <td><?php echo $row['user_name']; ?> </td>
                <td><?php echo $row['task_name'] ;?></td>
                <td><?php echo $row['task_description'];?> </td>
                <td><?php echo "Remarks"?> </td>
                <td>
              <?php 
                $images=$row['task_file'];
                $taskname=$row['task_name'];
                $temp = explode('*',$images);
                for($i=0;$i<count($temp);$i++)
                {
            echo' 
                <img class="example-image img-responsive" src="../upload/'.trim($temp[$i]).'"  width="50" height="50" alt="My Files"/> '; 
            /*<div class="gallery-grids agileits-w3layouts">
              <div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img"> 
              <a class="example-image-link w3-agilepic" href="../upload/'.trim($temp[$i]).'"  data-lightbox="example-set" data-title="My Daily Task">
                <img class="example-image img-responsive" src="../upload/'.trim($temp[$i]).'"  width="50" height="50" alt="My Files"/> 
                <div class="w3ls-overlay">
                  <h6>Daily Task</h6>
                </div> 
              </a> 
              </div>  
            </div>'; */
          }
        ?>  
              </td>
              </tr>  
            <?php $j++; }?>
              </tbody>
          </table>
          </div>
        </div> 
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer1">
      <div class="container">
        <div class="text-center">
          <small>Copyright © EdCloud Solution 2018</small>
          
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="index.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>
<script src="../vendor/jquery/jquery.min.js"></script>
   <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="../vendor/datatables/jquery.dataTables.js"></script>
    <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>
     <script src="../js/sb-admin-datatables.min.js"></script>