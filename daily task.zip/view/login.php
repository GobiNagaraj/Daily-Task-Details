<?php 
  
  if (isset($_GET['status'])) 
    {
      switch ($_GET['status']) 
      {
          case 'Login_error':
          echo "<div class='col-md-offset-3 alert alert-danger'> Please check Entered Details </div>";
          break;
      }
    }

 ?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Daily Task Edcloud Solution</title>
      <link rel="stylesheet" href="../css/login.css">  
 <!--      <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->
</head>

<body>

  <div class="materialContainer">
   <div class="box">
      <div class="logo"><img src="../images/ed.jpg" alt="EdCloud Solution"></div>
    <form action="../controller/admin-controller.php" method="POST">
      <div class="input">
         <label for="name">Admin Mail</label>
         <input type="email" name="admin_name" id="name">
         <span class="spin"></span>
      </div>
 
      <div class="input">
         <label for="pass">Password</label>
         <input type="password" name="admin_password" id="pass">
         <span class="spin"></span>
      </div>

  
        <input type="submit" value="Login" >
   
      </form>
   </div>

   <div class="overbox">
      <div class="material-button alt-2"><span class="shape"></span></div>

    <form action="../controller/login-controller.php" method="POST">
      <div class="title">Employee Login</div>
      <div class="input">
         <label for="regname">Employee Mail</label>
         <input type="email" name="user_mail" id="regname">
         <span class="spin"></span>
      </div>

      <div class="input">
         <label for="regpass">Password</label>
         <input type="password" name="user_password" id="regpass">
         <span class="spin"></span>
      </div>
    
          <div class="button">
         <button><span>Login</span></button>
      </div>
    
     </form>
   </div>
</div>
    <script src="../js/jquery.min.js"></script>
    <script  src="../js/index.js"></script>

</body>
</html>



<style>
input[type="submit"] {
    background: blue;
    color: white;
    width: 100%;
    margin: 20px auto;
    padding: 10px;
    font-size: 1.5em;
    font-family: 'monotype corsiva';
}
</style>