<?php 
  //session_start();
  include_once '../model/db.php';

 ?>
 <style type="text/css">
  a.active
  {
    background-color: royalblue;
  }
  #logout:hover
  {
    background-color: red;
  }
</style>
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="#"><blue>Ed</blue><orange>Cloud</orange> Solution</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
      <br>
        <li class="nav-item" id="dailytask" title="Daily Task">
          <a class="nav-link" href="#">
            <img src="../images/cloud.png" alt="edcloud" width="50">
            <span>Daily <small>Task</small></span>
          </a>
        </li>
      </ul>
   <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
      <li class="nav-item">
          <form class="form-inline my-2 my-lg-0 mr-lg-2" method="POST" action="admin_search.php">
            <div class="input-group">
              <input name="emp_search" class="form-control" type="text" >
              <span class="input-group-btn">
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
              </span>
            </div>
          </form>
        </li> 

        <li class="nav-item">
          <a class="nav-link  mr-lg-2 active"  href="#"  aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-fw fa-user"></i>Admin</a></li>
        <li class="nav-item" id="logout">
          <a class="nav-link" href="login.php"> 
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>


      </ul>
    </div>
  </nav>


  <style>
  #dailytask
  {
    margin:55% 0 0 0;
  }
  #dailytask span
  {
    color:white;
    font-size: 1.5em;
  }
  blue
  {
    color:royalblue;
  }
  orange{
    color:orangered;
  }
  
  @media(max-width: 768px){
      #dailytask
  {
    margin:0;
  }
  }
  </style>