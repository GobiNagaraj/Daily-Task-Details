<?php 
  session_start();
  include_once '../model/db.php';
  $variable = $_SESSION['user_data']['id'];
  //echo $variable;
  if($variable == "")
  {
    header('Location: login.php');
  }
  
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>EdCloud Task Page</title>
  <!-- Bootstrap core CSS-->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin.css" rel="stylesheet">
      

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
 
       <?php include_once 'menu.php';?>

<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../vendor1/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../vendor1/animate/animate.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../vendor1/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../vendor1/select2/select2.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="../css/util.css">
  <link rel="stylesheet" type="text/css" href="../css/main.css">
<!--===============================================================================================-->

<div class="content-wrapper">
    <div class="container-fluid">
      <?php 
        if (isset($_GET['status'])) 
          {
            switch ($_GET['status']) 
            {
                case 'Login_success':
                echo "<div class='col-md-offset-3 alert alert-success'>Login Successfully...</div>";
                break;    
            }
          }
       ?>
    <div class="dailynew">
      <div class="contact1">
    <div class="container-contact1">
      <div class="contact1-pic js-tilt" data-tilt>
        <img src="../images/img-01.png" alt="IMG">
      </div>

      <form class="contact1-form validate-form" method="POST" enctype="multipart/form-data" action="../controller/save-controller.php">
        <span class="contact1-form-title">
          Enroll Task Details
        </span>

        <div class="wrap-input1 validate-input">
          <input class="input1" type="text" name="user_name" value="<?php echo $_SESSION['user_data']['user_name']; ?>" readonly>
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input">
          <input class="input1" type="text" name="date" value="<?php echo date("Y/m/d"); ?>" readonly>
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input">
          <input class="input1" type="text" name="task_name" placeholder="Task Name" required>
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input">
          <textarea class="input1" name="task_description" placeholder="Task Description" required></textarea>
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input">
          <input class="input1" type="file" id="file" name="task_file[]" multiple accept="image/*" />
          <!-- <input class="input1" type="file" name="task_file" required> -->
          <span class="shadow-input1"></span>
        </div>

        <div class="wrap-input1 validate-input">
          <input type="text" class="input1" name="tom_task" placeholder="What is Your Tomorrow Task?" required>
          <span class="shadow-input1"></span>
        </div>

        <div class="container-contact1-form-btn">
          <button class="contact1-form-btn">
            <span>
              Send Email
              <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </span>
          </button>
        </div>
      </form>
      </div>
    </div>
  </div>     
  </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © EdCloud Solution 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="index.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../vendor/datatables/jquery.dataTables.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin.min.js"></script>
<!--===============================================================================================-->
  <script src="../vendor1/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../vendor1/bootstrap/js/popper.js"></script>

<script >
    $('.js-tilt').tilt({
      scale: 1.1
    })
  </script>
  <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

<!--===============================================================================================-->
  <script src="../js/main.js"></script>