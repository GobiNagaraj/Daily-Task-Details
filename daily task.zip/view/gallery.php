<html>
<head>
<link href="../css/gallery.css" rel="stylesheet">
 <link rel="stylesheet" href="../css/lightbox.css">
</head>

<body>
<div class="gallery-grids agileits-w3layouts">
          <div class="col-md-4 gallery-grid-img"> 
            <a class="example-image-link w3-agilepic" href="../upload/'.trim($temp[$i]).'"  data-lightbox="example-set" data-title="My Daily Task">
              <img class="example-image img-responsive" src="../upload/'.trim($temp[$i]).'"  width="50" height="50" alt="My Files"/> 
              <div class="w3ls-overlay">
                <h6>Daily Task</h6>
              </div> 
            </a> 
          </div>  
                </div>
 </body>
 </html>












 