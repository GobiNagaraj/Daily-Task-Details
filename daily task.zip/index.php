<?php 
	session_start();
	header('Location: view/login.php');

	session_destroy();
 ?>