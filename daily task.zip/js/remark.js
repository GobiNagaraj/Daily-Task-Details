//call magnificPopup when click btn
$('.open-delete-confirm').magnificPopup({
            mainClass: 'delete-modal',
            type:'inline',
            showCloseBtn: false,
            midClick: true, // Allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source in href.
             closeOnBgClick: false,
             enableEscapeKey: false,
             callbacks: {
                open: function() {
                    this.content.fadeIn();
                    this.content.find('.close-btn').on('click', function(){$.magnificPopup.close();});
                    this.content.off('click').on('click', '.close-modal', function(){
                        alert('Your Comments Send Successfully...');
                    });
                    
                }
            }
        });