<?php 	
	session_start();
	include_once '../model/db.php';

 		extract($_POST);
 		$user_name = $_POST['user_name'];
		$date = $_POST['date'];
		$task_name = $_POST['task_name'];
		$task_description = $_POST['task_description'];
		$tom_task = $_POST['tom_task'];
		$user_id = $_SESSION['user_data']['id'];
		
    if(isset($_FILES['task_file']['name']))
    {
        $file_name_all="";
        for($i=0; $i<count($_FILES['task_file']['name']); $i++) 
        {
               $tmpFilePath = $_FILES['task_file']['tmp_name'][$i];    
               if ($tmpFilePath != "")
               {    
                  $path = "../upload/"; // create folder 
                  $name = $_FILES['task_file']['name'][$i];
                  $size = $_FILES['task_file']['size'][$i];

                  list($txt, $ext) = explode(".", $name);
                  $file= time().substr(str_replace(" ", "_", $txt), 0);
                  $info = pathinfo($file);
                  $filename = $file.".".$ext;
                  if(move_uploaded_file($_FILES['task_file']['tmp_name'][$i], $path.$filename)) 
                   { 
                      $file_name_all.=$filename."*";
                   }
             }
        }
        $filepath = rtrim($file_name_all, '*'); 
        $query=mysqli_query($conn,"INSERT into task_details (`user_name`, `date`, `task_name`, `task_description`, `task_file`,`tom_task`, `session_id`) VALUES('$user_name', '$date', '$task_name', '$task_description', '".addslashes($filepath)."','$tom_task', '$user_id'); ");    
        
       
        
        }
        // else
        // {
        //     $filepath="";
        // }

      if($query)
      {
         //echo $query;
         
       
         $to= 'rahuman.btech@gmail.com,sureshkmr.IT@gmail.com';
        // $to = 'ngobicse@gmail.com';
         $sub='EdCloud Team Daily task';
         $link = 'https://dailytask.edcloudtrack.com';
        
         
         $message=  $user_name . 'Task is completed...! 
         
          Task Name:'.$task_name.'  
          
          Task Description:'.$task_description.' 
         
         '.$link.' ';
         
        

         $headers=''."\r\n";
         $send=mail($to,$sub,$message,$headers);

        if($send)
        {
        	header('location:../view/show.php');
        }
        
        else
        {
        echo"Sorry";
        }
         
     }
?>
 