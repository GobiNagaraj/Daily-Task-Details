<?php 
	
	session_start();
	include_once '../model/db.php';

	// username and password sent from form
	$form_uname = $_POST['user_mail'];
	$form_passwd = $_POST['user_password'];

	$sql="SELECT * FROM `employees` WHERE user_mail='$form_uname' and user_password='$form_passwd'";
	$result=mysqli_query($conn, $sql);
	$user_data = mysqli_fetch_array($result, MYSQLI_ASSOC);
	
	if(empty($user_data))
	{
		header('Location: ../view/login.php?status=Login_error');
		//echo "Success";
	}
	else 
	{
		//echo "Error";
		$_SESSION['user_data'] = $user_data;
		header('Location: ../view/task.php?status=Login_success');		
	}

 ?>