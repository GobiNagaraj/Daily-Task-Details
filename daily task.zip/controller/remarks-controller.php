<?php 	
	session_start();
	include_once '../model/db.php';

	$emp_name = $_POST['re_user_name'];
	$task_name = $_POST['re_task_name'];
	$task_update = $_POST['re_task_update'];
	$task_command = $_POST['re_task_commands'];
	$user_id = $_POST['session_id'];
 
	$query=mysqli_query($conn,"INSERT into admin_remarks (`date`,`emp_name`,`task_name`,`task_update`,`task_command`, `session_id`) VALUES('".date('Y-m-d')."','$emp_name','$task_name','$task_update', '$task_command', '$user_id'); "); 
        
      if($query)
      {
         //echo $query;
         header('Location: ../view/admin.php?status=remark_send');
      }
      else
      {
      	 //echo 'false';
          //echo $query;
      	 header('Location: ../view/admin.php?status=remark_error');
      }

?>

