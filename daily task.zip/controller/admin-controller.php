<?php 
	/*Admin Credentials*/
    //session_start();
    $admin_name = "admin@edcloud.com";
	$admin_password = "Admin@001";

	if($_POST['admin_name']==$admin_name && $_POST['admin_password']==$admin_password)
	{
		header('Location: ../view/admin.php?status=Login_success');

	}
	else
	{
		
		header('Location: ../view/login.php?status=Login_error');
	}

 ?>