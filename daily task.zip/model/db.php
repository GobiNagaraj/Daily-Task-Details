<?php 
	$hostname = "localhost";
	$username = "edcloudt_root";
	$password = "edcloudsolution12345";
	$dbname = "edcloudt_daily_task";

	$conn = mysqli_connect($hostname, $username, $password, $dbname);
	if(!$conn)
	{
		echo "Error" .mysqli_connect_error();
	}

 ?>